var red = [359, 100, 29.8];
var orange = [40, 100, 60];
var green = [75, 100, 40];
var blue = [196, 77, 55];
var purple = [280, 50, 60];
var bluefield = [199, 100, 22.9];

var color = [bluefield, purple, blue, green, orange, red];
var text = "Start learning!";

drawName(text, color);

bounceBubbles();